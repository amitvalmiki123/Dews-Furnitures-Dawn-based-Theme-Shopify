/* ==========================================================================
   Dew's Furniture — homepage interactions
   Vanilla JS, no dependencies. Every module bails out safely if its markup
   isn't on the page, so sections can be reordered or removed freely (which
   matters once these become individually toggleable Shopify sections).
   ========================================================================== */
(function () {
  'use strict';

  var $  = function (sel, ctx) { return (ctx || document).querySelector(sel); };
  var $$ = function (sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); };

  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ------------------------------------------------------------------
     Header — solid/bordered once the page has scrolled
     ------------------------------------------------------------------ */
  (function header() {
    var el = $('#header');
    if (!el) return;

    var onScroll = function () {
      el.classList.toggle('is-stuck', window.scrollY > 8);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  })();

  /* ------------------------------------------------------------------
     Search panel
     ------------------------------------------------------------------ */
  (function search() {
    var panel = $('#search');
    var open  = $('#searchBtn');
    var close = $('#searchClose');
    var input = $('#searchInput');
    if (!panel || !open) return;

    var setOpen = function (state) {
      panel.classList.toggle('is-open', state);
      open.setAttribute('aria-expanded', String(state));
      if (state && input) input.focus();
    };

    open.addEventListener('click', function () {
      setOpen(!panel.classList.contains('is-open'));
    });
    if (close) close.addEventListener('click', function () { setOpen(false); open.focus(); });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && panel.classList.contains('is-open')) {
        setOpen(false);
        open.focus();
      }
    });
  })();

  /* ------------------------------------------------------------------
     Mobile drawer
     ------------------------------------------------------------------ */
  (function drawer() {
    var el    = $('#drawer');
    var scrim = $('#scrim');
    var open  = $('#menuBtn');
    var close = $('#drawerClose');
    if (!el || !open) return;

    var setOpen = function (state) {
      el.classList.toggle('is-open', state);
      if (scrim) {
        scrim.classList.toggle('is-open', state);
        scrim.hidden = !state;
      }
      open.setAttribute('aria-expanded', String(state));
      document.body.style.overflow = state ? 'hidden' : '';
      if (state && close) close.focus();
    };

    open.addEventListener('click', function () { setOpen(true); });
    if (close) close.addEventListener('click', function () { setOpen(false); open.focus(); });
    if (scrim) scrim.addEventListener('click', function () { setOpen(false); });

    // close when a destination is picked
    $$('a', el).forEach(function (a) {
      a.addEventListener('click', function () { setOpen(false); });
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && el.classList.contains('is-open')) {
        setOpen(false);
        open.focus();
      }
    });

    // collapsible sub-menus
    $$('.drawer__toggle', el).forEach(function (btn) {
      var sub = document.getElementById(btn.getAttribute('aria-controls'));
      if (!sub) return;

      btn.addEventListener('click', function () {
        var isOpen = btn.classList.toggle('is-open');
        btn.setAttribute('aria-expanded', String(isOpen));
        sub.style.maxHeight = isOpen ? sub.scrollHeight + 'px' : '0px';
      });
    });
  })();

  /* ------------------------------------------------------------------
     Room index — hovering/focusing a room swaps the large stage image
     ------------------------------------------------------------------ */
  (function rooms() {
    var list  = $('#roomsList');
    var stage = $('#roomsStage');
    if (!list || !stage) return;

    var items  = $$('.rooms__item', list);
    var frames = $$('img', stage);

    var activate = function (index) {
      items.forEach(function (item, i) { item.classList.toggle('is-active', i === index); });
      frames.forEach(function (img, i) { img.classList.toggle('is-active', i === index); });
    };

    items.forEach(function (item, i) {
      item.addEventListener('mouseenter', function () { activate(i); });
      item.addEventListener('focusin', function () { activate(i); });
    });
  })();

  /* ------------------------------------------------------------------
     Hero hotspots — hover on desktop (CSS), tap to toggle on touch
     ------------------------------------------------------------------ */
  (function hotspots() {
    var spots = $$('.hotspot');
    if (!spots.length) return;

    spots.forEach(function (spot) {
      spot.addEventListener('click', function (e) {
        e.preventDefault();
        var wasOpen = spot.classList.contains('is-open');
        spots.forEach(function (s) { s.classList.remove('is-open'); });
        spot.classList.toggle('is-open', !wasOpen);
      });
    });

    document.addEventListener('click', function (e) {
      if (!e.target.closest('.hotspot')) {
        spots.forEach(function (s) { s.classList.remove('is-open'); });
      }
    });
  })();

  /* ------------------------------------------------------------------
     Product rail — arrows + scroll progress bar
     ------------------------------------------------------------------ */
  (function rails() {
    $$('[data-rail]').forEach(function (rail) {
      var track = $('[data-rail-track]', rail);
      var bar   = $('[data-rail-bar]', rail);
      var prev  = $('[data-rail-prev]', rail);
      var next  = $('[data-rail-next]', rail);
      if (!track) return;

      var page = function () {
        // scroll by one visible "page" minus a little, so the next card peeks in
        return Math.max(track.clientWidth * 0.8, 240);
      };

      var update = function () {
        var max = track.scrollWidth - track.clientWidth;

        if (bar) {
          var visible = track.clientWidth / track.scrollWidth;
          var ratio   = max > 0 ? track.scrollLeft / max : 0;
          bar.style.width = Math.max(visible * 100, 12) + '%';
          // translate within the remaining track space
          bar.style.transform = 'translateX(' + (ratio * ((1 / Math.max(visible, 0.12)) - 1) * 100) + '%)';
        }
        if (prev) prev.disabled = track.scrollLeft <= 2;
        if (next) next.disabled = track.scrollLeft >= max - 2;
      };

      if (prev) prev.addEventListener('click', function () { track.scrollBy({ left: -page(), behavior: reduceMotion ? 'auto' : 'smooth' }); });
      if (next) next.addEventListener('click', function () { track.scrollBy({ left:  page(), behavior: reduceMotion ? 'auto' : 'smooth' }); });

      track.addEventListener('scroll', update, { passive: true });
      window.addEventListener('resize', update);
      update();
    });
  })();

  /* ------------------------------------------------------------------
     Wishlist toggle (visual only — wire to the Shopify cart/wishlist app)
     ------------------------------------------------------------------ */
  (function wishlist() {
    $$('[data-wishlist]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var saved = btn.classList.toggle('is-saved');
        btn.setAttribute('aria-pressed', String(saved));
      });
    });
  })();

  /* ------------------------------------------------------------------
     Quick view modal
     ------------------------------------------------------------------ */
  (function quickview() {
    var modal = $('#quickview');
    if (!modal) return;

    var img   = $('#qvImg');
    var name  = $('#qvName');
    var price = $('#qvPrice');
    var was   = $('#qvWas');
    var desc  = $('#qvDesc');
    var close = $('#qvClose');
    var lastFocus = null;

    var setOpen = function (state) {
      modal.classList.toggle('is-open', state);
      modal.hidden = !state;
      document.body.style.overflow = state ? 'hidden' : '';
      if (state) {
        if (close) close.focus();
      } else if (lastFocus) {
        lastFocus.focus();
      }
    };

    $$('[data-quickview]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        lastFocus = btn;
        var wasPrice = btn.dataset.was || '';

        if (img)   { img.src = btn.dataset.img || ''; img.alt = btn.dataset.name || ''; }
        if (name)  name.textContent  = btn.dataset.name || '';
        if (price) price.textContent = btn.dataset.price || '';
        if (was)   { was.textContent = wasPrice; was.style.display = wasPrice ? '' : 'none'; }
        if (desc)  desc.textContent  = btn.dataset.desc || '';

        setOpen(true);
      });
    });

    if (close) close.addEventListener('click', function () { setOpen(false); });
    modal.addEventListener('click', function (e) { if (e.target === modal) setOpen(false); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && modal.classList.contains('is-open')) setOpen(false);
    });
  })();

  /* ------------------------------------------------------------------
     FAQ accordion — one open at a time
     ------------------------------------------------------------------ */
  (function faq() {
    var items = $$('.faq__item');
    if (!items.length) return;

    var setOpen = function (item, state) {
      var panel = $('.faq__a', item);
      var btn   = $('.faq__q', item);
      item.classList.toggle('is-open', state);
      if (btn)   btn.setAttribute('aria-expanded', String(state));
      if (panel) panel.style.maxHeight = state ? panel.scrollHeight + 'px' : '0px';
    };

    items.forEach(function (item) {
      var btn = $('.faq__q', item);
      if (!btn) return;

      // sync any item marked open in the markup
      if (item.classList.contains('is-open')) setOpen(item, true);

      btn.addEventListener('click', function () {
        var willOpen = !item.classList.contains('is-open');
        items.forEach(function (other) { setOpen(other, false); });
        setOpen(item, willOpen);
      });
    });

    // Re-measure any open panel whenever the text can reflow. Without the
    // font/load passes the default-open item gets sized against fallback-font
    // metrics and ends up with a wildly wrong max-height.
    var resync = function () {
      items.forEach(function (item) {
        if (item.classList.contains('is-open')) setOpen(item, true);
      });
    };

    window.addEventListener('resize', resync);
    window.addEventListener('load', resync);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(resync);
  })();

  /* ------------------------------------------------------------------
     Reveal on scroll
     ------------------------------------------------------------------ */
  (function reveal() {
    var els = $$('.reveal, .reveal-img');
    if (!els.length) return;

    if (reduceMotion || !('IntersectionObserver' in window)) {
      els.forEach(function (el) { el.classList.add('is-in'); });
      return;
    }

    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-in');
        io.unobserve(entry.target);
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });

    els.forEach(function (el) { io.observe(el); });

    // Safety net. The reveal start state hides content, so anything that stops
    // the observer from reporting (embedded webviews, throttled background
    // tabs, a tall element that never hits the threshold) would leave a section
    // permanently blank. This rect check reveals on the same trigger point, so
    // when the observer does work it simply never has anything left to do.
    var sweep = function () {
      var vh = window.innerHeight || document.documentElement.clientHeight;
      els.forEach(function (el) {
        if (el.classList.contains('is-in')) return;
        var r = el.getBoundingClientRect();
        if (r.top < vh * 0.92 && r.bottom > 0) el.classList.add('is-in');
      });
    };

    window.addEventListener('scroll', sweep, { passive: true });
    window.addEventListener('resize', sweep);
    window.addEventListener('load', sweep);
    sweep();
  })();

  /* ------------------------------------------------------------------
     Promo countdown
     ------------------------------------------------------------------ */
  (function countdown() {
    var root = $('#countdown');
    if (!root) return;

    var d = $('#cd-d'), h = $('#cd-h'), m = $('#cd-m'), s = $('#cd-s');
    if (!d || !h || !m || !s) return;

    // Demo behaviour: a rolling window from first visit. For production, set a
    // real end timestamp from the Shopify section settings instead.
    var hours = parseInt(root.dataset.hours, 10) || 72;
    var key   = 'dews-offer-end';
    var end   = parseInt(window.localStorage.getItem(key), 10);

    if (!end || isNaN(end) || end < Date.now()) {
      end = Date.now() + hours * 3600 * 1000;
      try { window.localStorage.setItem(key, String(end)); } catch (e) { /* private mode */ }
    }

    var pad = function (n) { return n < 10 ? '0' + n : String(n); };

    var tick = function () {
      var left = Math.max(0, end - Date.now());
      var secs = Math.floor(left / 1000);

      d.textContent = pad(Math.floor(secs / 86400));
      h.textContent = pad(Math.floor(secs / 3600) % 24);
      m.textContent = pad(Math.floor(secs / 60) % 60);
      s.textContent = pad(secs % 60);
    };

    tick();
    setInterval(tick, 1000);
  })();

  /* ------------------------------------------------------------------
     Newsletter — client-side validation only; wire to Shopify/Klaviyo
     ------------------------------------------------------------------ */
  (function newsletter() {
    var form = $('#newsForm');
    var msg  = $('#formMsg');
    if (!form) return;

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var input = $('#newsEmail');
      var value = input ? input.value.trim() : '';
      var valid = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value);

      if (!msg) return;
      msg.textContent = valid
        ? 'Thanks — check your inbox to confirm your subscription.'
        : 'Please enter a valid email address.';
      msg.className = 'form-msg ' + (valid ? 'is-ok' : 'is-err');

      if (valid) form.reset();
      else if (input) input.focus();
    });
  })();

  /* ------------------------------------------------------------------
     Mobile sticky CTA — appears once the hero is behind you
     ------------------------------------------------------------------ */
  (function mobileCta() {
    var bar = $('#mobileCta');
    if (!bar) return;

    var onScroll = function () {
      var show = window.scrollY > window.innerHeight * 0.6;
      bar.classList.toggle('is-visible', show);
      document.body.classList.toggle('has-mobile-cta', show);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  })();

  /* ==================================================================
     INNER PAGES — collection + product detail
     Each module below no-ops when its markup is absent, so all three
     templates can share this one file.
     ================================================================== */

  /* ------------------------------------------------------------------
     Product gallery — thumbnail switching + click-to-zoom
     ------------------------------------------------------------------ */
  (function gallery() {
    var root = $('#gallery');
    if (!root) return;

    var main  = $('#galleryMain');
    var img   = $('#galleryImg');
    var thumbs = $$('.gallery__thumb', root);
    if (!main || !img) return;

    thumbs.forEach(function (thumb) {
      thumb.addEventListener('click', function () {
        var full = thumb.dataset.full;
        if (!full) return;

        img.src = full;
        thumbs.forEach(function (t) {
          var on = t === thumb;
          t.classList.toggle('is-active', on);
          t.setAttribute('aria-selected', String(on));
        });
        // a new image invalidates any zoom already applied
        main.classList.remove('is-zoomed');
        img.style.transformOrigin = 'center';
      });
    });

    main.addEventListener('click', function () {
      main.classList.toggle('is-zoomed');
    });

    // While zoomed, track the pointer so the origin follows the cursor.
    main.addEventListener('mousemove', function (e) {
      if (!main.classList.contains('is-zoomed')) return;
      var r = main.getBoundingClientRect();
      var x = ((e.clientX - r.left) / r.width) * 100;
      var y = ((e.clientY - r.top) / r.height) * 100;
      img.style.transformOrigin = x + '% ' + y + '%';
    });

    main.addEventListener('mouseleave', function () {
      main.classList.remove('is-zoomed');
      img.style.transformOrigin = 'center';
    });
  })();

  /* ------------------------------------------------------------------
     Variant pickers — visual only; wire to the Shopify variant API
     ------------------------------------------------------------------ */
  (function variants() {
    var groups = {};
    $$('[data-opt]').forEach(function (btn) {
      (groups[btn.dataset.opt] = groups[btn.dataset.opt] || []).push(btn);
    });

    Object.keys(groups).forEach(function (name) {
      var labelEl = $('#opt' + name.charAt(0).toUpperCase() + name.slice(1));

      groups[name].forEach(function (btn) {
        btn.addEventListener('click', function () {
          if (btn.disabled) return;
          groups[name].forEach(function (b) { b.setAttribute('aria-pressed', 'false'); });
          btn.setAttribute('aria-pressed', 'true');
          if (labelEl) labelEl.textContent = btn.dataset.name || btn.textContent.trim();
        });
      });
    });
  })();

  /* ------------------------------------------------------------------
     Quantity stepper
     ------------------------------------------------------------------ */
  (function quantity() {
    var input = $('#qtyInput');
    if (!input) return;

    $$('[data-qty]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var step = parseInt(btn.dataset.qty, 10) || 0;
        var min  = parseInt(input.min, 10) || 1;
        var max  = parseInt(input.max, 10) || 99;
        var next = (parseInt(input.value, 10) || min) + step;
        input.value = Math.min(max, Math.max(min, next));
      });
    });

    // guard against typed-in junk
    input.addEventListener('change', function () {
      var min = parseInt(input.min, 10) || 1;
      var max = parseInt(input.max, 10) || 99;
      var v = parseInt(input.value, 10);
      input.value = isNaN(v) ? min : Math.min(max, Math.max(min, v));
    });
  })();

  /* ------------------------------------------------------------------
     Sticky add-to-cart — shows once the real buy row scrolls past
     ------------------------------------------------------------------ */
  (function stickyAtc() {
    var bar = $('#stickyAtc');
    var row = $('#buyRow');
    if (!bar || !row) return;

    var onScroll = function () {
      var past = row.getBoundingClientRect().bottom < 0;
      bar.classList.toggle('is-visible', past);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    onScroll();
  })();

  /* ------------------------------------------------------------------
     Facet accordions (filter rail + filter drawer)
     ------------------------------------------------------------------ */
  (function facets() {
    $$('.facet__q').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var facet = btn.closest('.facet');
        if (!facet) return;
        var closed = facet.classList.toggle('is-closed');
        btn.setAttribute('aria-expanded', String(!closed));
      });
    });
  })();

  /* ------------------------------------------------------------------
     Mobile filter drawer
     ------------------------------------------------------------------ */
  (function filterDrawer() {
    var el    = $('#filterDrawer');
    var open  = $('#filtersOpen');
    var close = $('#filtersClose');
    var apply = $('#filtersApply');
    var scrim = $('#scrim');
    if (!el || !open) return;

    var setOpen = function (state) {
      el.classList.toggle('is-open', state);
      el.hidden = !state;
      open.setAttribute('aria-expanded', String(state));
      if (scrim) {
        scrim.classList.toggle('is-open', state);
        scrim.hidden = !state;
      }
      document.body.style.overflow = state ? 'hidden' : '';
      if (state && close) close.focus();
    };

    open.addEventListener('click', function () { setOpen(true); });
    if (close) close.addEventListener('click', function () { setOpen(false); open.focus(); });
    if (apply) apply.addEventListener('click', function () { setOpen(false); open.focus(); });
    if (scrim) scrim.addEventListener('click', function () {
      if (el.classList.contains('is-open')) setOpen(false);
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && el.classList.contains('is-open')) {
        setOpen(false);
        open.focus();
      }
    });
  })();

  /* ------------------------------------------------------------------
     Collection filtering, sorting and load-more.

     Filters really run against the cards' data attributes rather than
     faking it, so the client can click through a genuine result set.
     In Shopify this is replaced by the Storefront filtering API, but the
     markup contract (data-room / data-material / data-colour / data-tag /
     data-price) maps straight onto product tags and metafields.
     ------------------------------------------------------------------ */
  (function collection() {
    var grid = $('#grid');
    if (!grid) return;

    var cards      = $$('.product', grid);
    var sortBy     = $('#sortBy');
    var chipsWrap  = $('#activeChips');
    var emptyState = $('#emptyState');
    var moreWrap   = $('#more');
    var loadMore   = $('#loadMore');
    var shownEl    = $('#shownCount');
    var totalEl    = $('#totalCount');
    var resultEl   = $('#resultCount');
    var drawerEl   = $('#drawerCount');
    var badgeEl    = $('#filterCount');

    var PAGE = 9;
    var shown = PAGE;

    // Keep the original order so "Featured" can be restored after sorting.
    cards.forEach(function (c, i) { c.dataset.order = i; });

    var labels = {
      living: 'Living Room', bedroom: 'Bedroom', dining: 'Dining', storage: 'Storage',
      sheesham: 'Sheesham', mango: 'Mango wood', linen: 'Natural linen', boucle: 'Bouclé',
      natural: 'Natural cane', espresso: 'Espresso', walnut: 'Walnut', ivory: 'Ivory', black: 'Black',
      instock: 'In stock', sale: 'On sale', 'new': 'New in'
    };

    var readFilters = function () {
      var picked = { room: [], material: [], colour: [], tag: [] };

      $$('input[data-filter]:checked').forEach(function (i) {
        if (picked[i.dataset.filter].indexOf(i.value) === -1) picked[i.dataset.filter].push(i.value);
      });
      $$('.swatch-opt[aria-pressed="true"]').forEach(function (b) {
        var v = b.getAttribute('value');
        if (picked.colour.indexOf(v) === -1) picked.colour.push(v);
      });

      var minEl = $('[data-price-min]');
      var maxEl = $('[data-price-max]');
      picked.min = minEl && minEl.value !== '' ? parseFloat(minEl.value) : null;
      picked.max = maxEl && maxEl.value !== '' ? parseFloat(maxEl.value) : null;
      return picked;
    };

    var matches = function (card, f) {
      var has = function (attr, list) {
        if (!list.length) return true;
        var vals = (card.dataset[attr] || '').split(/\s+/);
        return list.some(function (v) { return vals.indexOf(v) !== -1; });
      };
      if (!has('room', f.room)) return false;
      if (!has('material', f.material)) return false;
      if (!has('colour', f.colour)) return false;
      if (!has('tag', f.tag)) return false;

      var price = parseFloat(card.dataset.price) || 0;
      if (f.min !== null && price < f.min) return false;
      if (f.max !== null && price > f.max) return false;
      return true;
    };

    var sortCards = function (list) {
      var mode = sortBy ? sortBy.value : 'featured';
      var n = function (c, k) { return parseFloat(c.dataset[k]) || 0; };

      return list.slice().sort(function (a, b) {
        switch (mode) {
          case 'price-asc':  return n(a, 'price') - n(b, 'price');
          case 'price-desc': return n(b, 'price') - n(a, 'price');
          case 'newest':     return n(a, 'date') - n(b, 'date');
          case 'best':       return n(b, 'sales') - n(a, 'sales');
          default:           return n(a, 'order') - n(b, 'order');
        }
      });
    };

    var renderChips = function (f) {
      if (!chipsWrap) return;
      var chips = [];

      ['room', 'material', 'colour', 'tag'].forEach(function (group) {
        f[group].forEach(function (v) {
          chips.push({ group: group, value: v, label: labels[v] || v });
        });
      });
      if (f.min !== null || f.max !== null) {
        chips.push({
          group: 'price', value: 'price',
          label: '$' + (f.min !== null ? f.min : 0) + ' – $' + (f.max !== null ? f.max : '2000+')
        });
      }

      chipsWrap.innerHTML = '';
      chips.forEach(function (c) {
        var el = document.createElement('span');
        el.className = 'chip';
        el.innerHTML = c.label +
          ' <button type="button" aria-label="Remove filter ' + c.label +
          '"><svg aria-hidden="true"><use href="#i-close"/></svg></button>';

        el.querySelector('button').addEventListener('click', function () {
          if (c.group === 'price') {
            $$('[data-price-min],[data-price-max]').forEach(function (i) { i.value = ''; });
          } else if (c.group === 'colour') {
            $$('.swatch-opt[value="' + c.value + '"]').forEach(function (b) { b.setAttribute('aria-pressed', 'false'); });
          } else {
            $$('input[data-filter="' + c.group + '"][value="' + c.value + '"]').forEach(function (i) { i.checked = false; });
          }
          apply();
        });
        chipsWrap.appendChild(el);
      });

      chipsWrap.hidden = chips.length === 0;
      if (badgeEl) {
        badgeEl.textContent = chips.length;
        badgeEl.hidden = chips.length === 0;
      }
    };

    var apply = function (resetPage) {
      var f = readFilters();
      if (resetPage !== false) shown = PAGE;

      var visible = cards.filter(function (c) { return matches(c, f); });

      // Re-append in sorted order; the grid only ever holds these nodes.
      sortCards(visible).forEach(function (c) { grid.appendChild(c); });

      cards.forEach(function (c) { c.hidden = true; });
      visible.slice(0, shown).forEach(function (c) { c.hidden = false; });

      var total = visible.length;
      if (resultEl) resultEl.textContent = total;
      if (totalEl)  totalEl.textContent  = total;
      if (drawerEl) drawerEl.textContent = total;
      if (shownEl)  shownEl.textContent  = Math.min(shown, total);

      if (emptyState) emptyState.hidden = total !== 0;
      if (moreWrap)   moreWrap.hidden   = total === 0 || shown >= total;

      var fill = $('#moreFill');
      if (fill) fill.style.width = (total ? Math.min(shown, total) / total * 100 : 0) + '%';

      renderChips(f);
    };

    // any control change re-runs the whole pipeline
    $$('input[data-filter]').forEach(function (i) { i.addEventListener('change', function () { apply(); }); });
    $$('[data-price-min],[data-price-max]').forEach(function (i) { i.addEventListener('input', function () { apply(); }); });
    $$('.swatch-opt').forEach(function (b) {
      b.addEventListener('click', function () {
        b.setAttribute('aria-pressed', b.getAttribute('aria-pressed') === 'true' ? 'false' : 'true');
        apply();
      });
    });
    if (sortBy) sortBy.addEventListener('change', function () { apply(false); });

    if (loadMore) loadMore.addEventListener('click', function () {
      shown += PAGE;
      apply(false);
    });

    $$('[data-clear-filters]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        $$('input[data-filter]').forEach(function (i) { i.checked = false; });
        $$('.swatch-opt').forEach(function (b) { b.setAttribute('aria-pressed', 'false'); });
        $$('[data-price-min],[data-price-max]').forEach(function (i) { i.value = ''; });
        if (sortBy) sortBy.value = 'featured';
        apply();
      });
    });

    // The rail and drawer share facet markup, so mirror checkbox state
    // between the two copies rather than letting them drift apart.
    $$('input[data-filter]').forEach(function (input) {
      input.addEventListener('change', function () {
        $$('input[data-filter="' + input.dataset.filter + '"][value="' + input.value + '"]')
          .forEach(function (twin) { if (twin !== input) twin.checked = input.checked; });
      });
    });
    $$('.swatch-opt').forEach(function (btn) {
      btn.addEventListener('click', function () {
        $$('.swatch-opt[value="' + btn.getAttribute('value') + '"]')
          .forEach(function (twin) { twin.setAttribute('aria-pressed', btn.getAttribute('aria-pressed')); });
      });
    });

    apply();
  })();

})();
