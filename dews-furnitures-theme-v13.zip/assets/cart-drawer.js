class CartDrawer extends HTMLElement {
  constructor() {
    super();

    this.addEventListener('keyup', (evt) => evt.code === 'Escape' && this.close());
    this.querySelector('#CartDrawer-Overlay').addEventListener('click', this.close.bind(this));
    this.setHeaderCartIconAccessibility();
  }

  setHeaderCartIconAccessibility() {
    const cartLink = document.querySelector('#cart-icon-bubble');
    if (!cartLink) return;

    cartLink.setAttribute('role', 'button');
    cartLink.setAttribute('aria-haspopup', 'dialog');
    cartLink.addEventListener('click', (event) => {
      event.preventDefault();
      this.open(cartLink);
    });
    cartLink.addEventListener('keydown', (event) => {
      if (event.code.toUpperCase() === 'SPACE') {
        event.preventDefault();
        this.open(cartLink);
      }
    });
  }

  open(triggeredBy) {
    if (this.classList.contains('active')) return;
    if (triggeredBy) this.setActiveElement(triggeredBy);
    const cartDrawerNote = this.querySelector('[id^="Details-"] summary');
    if (cartDrawerNote && !cartDrawerNote.hasAttribute('role')) this.setSummaryAccessibility(cartDrawerNote);
    // here the animation doesn't seem to always get triggered. A timeout seem to help
    setTimeout(() => {
      this.classList.add('animate', 'active');
    });

    this.addEventListener(
      'transitionend',
      () => {
        const containerToTrapFocusOn = this.classList.contains('is-empty')
          ? this.querySelector('.drawer__inner-empty')
          : document.getElementById('CartDrawer');
        const focusElement = this.querySelector('.drawer__inner') || this.querySelector('.drawer__close');
        trapFocus(containerToTrapFocusOn, focusElement);
      },
      { once: true },
    );

    /* Lock the scroll on <html>, NOT <body>.
       style.css sets `html { overflow-x: clip }`, so html's overflow is no
       longer `visible` — which means body's overflow stops propagating to the
       viewport. Adding `overflow:hidden` to body therefore turned body into
       the scroll container, and every position:sticky descendant (the header
       group) re-anchored to body's non-scrolling scrollport: on a scrolled
       page the header snapped to the top of the document and looked like it
       vanished, while the page kept its scroll offset so nothing else moved.
       html IS the viewport scroll container, so locking it disables scrolling
       while leaving sticky elements stuck where they are. */
    document.documentElement.classList.add('overflow-hidden');

    // cart-drawer-items is a CartItems subclass that extends createViewEventElement.
    // Its `view-event-trigger="manual"` skips auto-dispatch on connect; we fire
    // it here when the drawer opens, with `context: 'dialog'` from the payload attribute.
    this.querySelector('cart-drawer-items')?.dispatchViewEvent();
  }

  close() {
    this.classList.remove('active');
    // Remember where the page was before closing. removeTrapFocus() hands focus
    // back to whatever opened the drawer (the cart icon in the header) and
    // toggling `overflow-hidden` on <html> can reset the offset on some
    // browsers — either one yanks a scrolled page back to the top. The .focus()
    // call is now preventScroll, and this puts the offset back if anything
    // else still moved it. The filter drawer and the mobile menu do not use
    // this path, which is why only the cart drawer jumped.
    const scrollY = window.scrollY;
    removeTrapFocus(this.activeElement);
    document.documentElement.classList.remove('overflow-hidden');
    if (window.scrollY !== scrollY) window.scrollTo(0, scrollY);
  }

  setSummaryAccessibility(cartDrawerNote) {
    cartDrawerNote.setAttribute('role', 'button');
    cartDrawerNote.setAttribute('aria-expanded', 'false');

    if (cartDrawerNote.nextElementSibling.getAttribute('id')) {
      cartDrawerNote.setAttribute('aria-controls', cartDrawerNote.nextElementSibling.id);
    }

    cartDrawerNote.addEventListener('click', (event) => {
      event.currentTarget.setAttribute('aria-expanded', !event.currentTarget.closest('details').hasAttribute('open'));
    });

    cartDrawerNote.parentElement.addEventListener('keyup', onKeyUpEscape);
  }

  renderContents(parsedState) {
    this.querySelector('.drawer__inner').classList.contains('is-empty') &&
      this.querySelector('.drawer__inner').classList.remove('is-empty');
    this.productId = parsedState.id;
    this.getSectionsToRender().forEach((section) => {
      const sectionElement = section.selector
        ? document.querySelector(section.selector)
        : document.getElementById(section.id);

      if (!sectionElement) return;
      sectionElement.innerHTML = this.getSectionInnerHTML(parsedState.sections[section.id], section.selector);
    });

    // Keep the host's is-empty flag in sync with the real item count.
    // The theme only ever REMOVED this class (and from .drawer__inner, not the
    // host), so after emptying the cart the freshly rendered markup kept BOTH
    // the empty-state close button and the normal header one — two X icons.
    // Guard: /cart/add.js answers with the LINE ITEM, which has no item_count,
    // so only sync when the count is actually present — otherwise adding from
    // the PDP would mark a full cart as empty. When it is absent fall back to
    // the markup itself: if the freshly rendered drawer has no empty-state
    // block, drop the flag, otherwise a stale is-empty hides the header and
    // leaves the drawer with no close button at all.
    if (typeof parsedState.item_count === 'number') {
      this.classList.toggle('is-empty', parsedState.item_count === 0);
    } else if (!this.querySelector('.drawer__inner-empty')) {
      this.classList.remove('is-empty');
    }

    setTimeout(() => {
      this.querySelector('#CartDrawer-Overlay').addEventListener('click', this.close.bind(this));
      this.open();
    });
  }

  getSectionInnerHTML(html, selector = '.shopify-section') {
    return new DOMParser().parseFromString(html, 'text/html').querySelector(selector).innerHTML;
  }

  getSectionsToRender() {
    return [
      {
        id: 'cart-drawer',
        selector: '#CartDrawer',
      },
      {
        id: 'cart-icon-bubble',
      },
    ];
  }

  getSectionDOM(html, selector = '.shopify-section') {
    return new DOMParser().parseFromString(html, 'text/html').querySelector(selector);
  }

  setActiveElement(element) {
    this.activeElement = element;
  }
}

customElements.define('cart-drawer', CartDrawer);

class CartDrawerItems extends CartItems {
  getSectionsToRender() {
    return [
      {
        id: 'CartDrawer',
        section: 'cart-drawer',
        selector: '.drawer__inner',
      },
      {
        id: 'cart-icon-bubble',
        section: 'cart-icon-bubble',
        selector: '.shopify-section',
      },
    ];
  }
}

customElements.define('cart-drawer-items', CartDrawerItems);
